CS-546-Final-Project

Final Project for CS-546: Web Programming  
Group24 Section A

How to Setup:
• Run ‘run npm install’ to install the dependencies
• Run ‘npm run seed’ to load the seed database
• The seed file creates admin user Admin214@gmail.com, password:1Admin214@gmail.com

How Application Works:
• The landing page of the website shows all the posts
• Authenticated user can like and comment on the post
• Unauthenticated user can only view the post
• Authenticated user can view their profile
• Authenticated user can update their information
